WiFi AIM test bundle - w_260822
IMPORTANT: firmware and APPS in this bundle are a matched set.
Back up the SD card before testing.
Copy APPS from this bundle together with flashing the included firmware.
Do not mix the WiFi AIM PPMA with stock n_260808 firmware.
